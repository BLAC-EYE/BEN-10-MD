70 path=X-HUNTER V4️⃣🩸/list/lib/lowdb/adapters/MemorySync.d.ts
