/* WELCOME TO X-HUNTER V4BUG BOT
CREATED BY
◎Cybervigilante
◎SNOWBIRD
◎THANKS FOR YOUR SUPPORT*/

const fs = require('fs')
const chalk = require('chalk')
//=================================================//
// setting bot
global.owner = "263780145644"
global.namaowner = "𝚂𝙽𝙾𝚆𝙱𝙸𝚁𝙳"
global.botname = "SNOWKILLER BUG BOT"
global.author = "263780145644"
global.xprefix = '.'
global.autostatusview = true 
//=================================================//
global.mess = {
    owner: '`command reserved for owner only<\>`',
    admin: '`command reserved for admins only<\>`',
    group: '`feature for group only<\>`',
    done: '`Done ✓`',
    error: 'Error !',
    success: 'Succes •'
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.green.bold(`Update ${__filename}`))
delete require.cache[file]
require(file)
})